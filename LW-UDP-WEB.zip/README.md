SIAM CODEX — Premium Level Up Command Center
========================================

Dashboard: http://localhost:31973
Admin Telegram: @SIAM_CODEX
Credit: SIAM CODEX

Premium refresh includes:
- SIAM CODEX rebrand and Level Up command-center identity
- New local dashboard port 31973
- Premium dark glass / neon cyan-violet visual system
- Hero command header and status badges
- Contact Admin Telegram button
- Account search
- Account filters: All / In Match / Ready
- EXP and Level sorting
- Live telemetry strip
- Improved responsive mobile layout
- Premium typography and spacing
- Stronger visual hierarchy
- Improved buttons, cards, shadows and borders
- Cleaner English microcopy
- Mobile safe-area friendly layout
- Existing API endpoints and worker flow preserved
